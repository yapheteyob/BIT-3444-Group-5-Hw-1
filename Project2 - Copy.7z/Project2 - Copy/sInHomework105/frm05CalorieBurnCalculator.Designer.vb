﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm05CalorieBurnCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.FileSystemWatcher1 = New System.IO.FileSystemWatcher()
        Me.pbx05ExercisePicture = New System.Windows.Forms.PictureBox()
        Me.lbl05Age = New System.Windows.Forms.Label()
        Me.lbl05Height = New System.Windows.Forms.Label()
        Me.lblWeight = New System.Windows.Forms.Label()
        Me.lbl05Exercise = New System.Windows.Forms.Label()
        Me.lbl05Hours = New System.Windows.Forms.Label()
        Me.lbl05Calorie = New System.Windows.Forms.Label()
        Me.lbl05Recommended = New System.Windows.Forms.Label()
        Me.lbl05CalorieCount = New System.Windows.Forms.Label()
        Me.lbl05RecommendedBurn = New System.Windows.Forms.Label()
        Me.lbl05ScrollBar = New System.Windows.Forms.Label()
        Me.txt05Age = New System.Windows.Forms.TextBox()
        Me.clx05Height = New System.Windows.Forms.CheckedListBox()
        Me.cbo05Exercise = New System.Windows.Forms.ComboBox()
        Me.hsb05Hours = New System.Windows.Forms.HScrollBar()
        Me.btn05Calculate = New System.Windows.Forms.Button()
        Me.btn05Close = New System.Windows.Forms.Button()
        Me.grp05DataEntry = New System.Windows.Forms.GroupBox()
        Me.grp05Results = New System.Windows.Forms.GroupBox()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbx05ExercisePicture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grp05DataEntry.SuspendLayout()
        Me.SuspendLayout()
        '
        'FileSystemWatcher1
        '
        Me.FileSystemWatcher1.EnableRaisingEvents = True
        Me.FileSystemWatcher1.SynchronizingObject = Me
        '
        'pbx05ExercisePicture
        '
        Me.pbx05ExercisePicture.Location = New System.Drawing.Point(12, 12)
        Me.pbx05ExercisePicture.Name = "pbx05ExercisePicture"
        Me.pbx05ExercisePicture.Size = New System.Drawing.Size(150, 75)
        Me.pbx05ExercisePicture.TabIndex = 0
        Me.pbx05ExercisePicture.TabStop = False
        '
        'lbl05Age
        '
        Me.lbl05Age.AutoSize = True
        Me.lbl05Age.Location = New System.Drawing.Point(12, 99)
        Me.lbl05Age.Name = "lbl05Age"
        Me.lbl05Age.Size = New System.Drawing.Size(154, 25)
        Me.lbl05Age.TabIndex = 1
        Me.lbl05Age.Text = "What is your age?"
        '
        'lbl05Height
        '
        Me.lbl05Height.AutoSize = True
        Me.lbl05Height.Location = New System.Drawing.Point(12, 157)
        Me.lbl05Height.Name = "lbl05Height"
        Me.lbl05Height.Size = New System.Drawing.Size(175, 25)
        Me.lbl05Height.TabIndex = 2
        Me.lbl05Height.Text = "What is your height?"
        '
        'lblWeight
        '
        Me.lblWeight.AutoSize = True
        Me.lblWeight.Location = New System.Drawing.Point(12, 205)
        Me.lblWeight.Name = "lblWeight"
        Me.lblWeight.Size = New System.Drawing.Size(178, 25)
        Me.lblWeight.TabIndex = 3
        Me.lblWeight.Text = "What is your weight?"
        '
        'lbl05Exercise
        '
        Me.lbl05Exercise.AutoSize = True
        Me.lbl05Exercise.Location = New System.Drawing.Point(16, 262)
        Me.lbl05Exercise.Name = "lbl05Exercise"
        Me.lbl05Exercise.Size = New System.Drawing.Size(356, 25)
        Me.lbl05Exercise.TabIndex = 4
        Me.lbl05Exercise.Text = "What form of exercise do you do regularly?"
        '
        'lbl05Hours
        '
        Me.lbl05Hours.AutoSize = True
        Me.lbl05Hours.Location = New System.Drawing.Point(12, 314)
        Me.lbl05Hours.Name = "lbl05Hours"
        Me.lbl05Hours.Size = New System.Drawing.Size(360, 25)
        Me.lbl05Hours.TabIndex = 5
        Me.lbl05Hours.Text = "How many hours per week do you exercise?"
        '
        'lbl05Calorie
        '
        Me.lbl05Calorie.AutoSize = True
        Me.lbl05Calorie.Location = New System.Drawing.Point(12, 368)
        Me.lbl05Calorie.Name = "lbl05Calorie"
        Me.lbl05Calorie.Size = New System.Drawing.Size(258, 25)
        Me.lbl05Calorie.TabIndex = 6
        Me.lbl05Calorie.Text = "Your average daily calorie burn:"
        '
        'lbl05Recommended
        '
        Me.lbl05Recommended.AutoSize = True
        Me.lbl05Recommended.Location = New System.Drawing.Point(299, 99)
        Me.lbl05Recommended.Name = "lbl05Recommended"
        Me.lbl05Recommended.Size = New System.Drawing.Size(312, 25)
        Me.lbl05Recommended.TabIndex = 7
        Me.lbl05Recommended.Text = "Your recommended daily calorie burn:"
        '
        'lbl05CalorieCount
        '
        Me.lbl05CalorieCount.AutoSize = True
        Me.lbl05CalorieCount.Location = New System.Drawing.Point(299, 157)
        Me.lbl05CalorieCount.Name = "lbl05CalorieCount"
        Me.lbl05CalorieCount.Size = New System.Drawing.Size(63, 25)
        Me.lbl05CalorieCount.TabIndex = 8
        Me.lbl05CalorieCount.Text = "Label1"
        '
        'lbl05RecommendedBurn
        '
        Me.lbl05RecommendedBurn.AutoSize = True
        Me.lbl05RecommendedBurn.Location = New System.Drawing.Point(299, 205)
        Me.lbl05RecommendedBurn.Name = "lbl05RecommendedBurn"
        Me.lbl05RecommendedBurn.Size = New System.Drawing.Size(63, 25)
        Me.lbl05RecommendedBurn.TabIndex = 9
        Me.lbl05RecommendedBurn.Text = "Label1"
        '
        'lbl05ScrollBar
        '
        Me.lbl05ScrollBar.AutoSize = True
        Me.lbl05ScrollBar.Location = New System.Drawing.Point(503, 157)
        Me.lbl05ScrollBar.Name = "lbl05ScrollBar"
        Me.lbl05ScrollBar.Size = New System.Drawing.Size(63, 25)
        Me.lbl05ScrollBar.TabIndex = 10
        Me.lbl05ScrollBar.Text = "Label1"
        '
        'txt05Age
        '
        Me.txt05Age.Location = New System.Drawing.Point(503, 199)
        Me.txt05Age.Name = "txt05Age"
        Me.txt05Age.Size = New System.Drawing.Size(150, 31)
        Me.txt05Age.TabIndex = 0
        '
        'clx05Height
        '
        Me.clx05Height.FormattingEnabled = True
        Me.clx05Height.Location = New System.Drawing.Point(473, 262)
        Me.clx05Height.Name = "clx05Height"
        Me.clx05Height.Size = New System.Drawing.Size(180, 144)
        Me.clx05Height.TabIndex = 1
        '
        'cbo05Exercise
        '
        Me.cbo05Exercise.FormattingEnabled = True
        Me.cbo05Exercise.Location = New System.Drawing.Point(628, 314)
        Me.cbo05Exercise.Name = "cbo05Exercise"
        Me.cbo05Exercise.Size = New System.Drawing.Size(182, 33)
        Me.cbo05Exercise.TabIndex = 2
        '
        'hsb05Hours
        '
        Me.hsb05Hours.Location = New System.Drawing.Point(656, 272)
        Me.hsb05Hours.Name = "hsb05Hours"
        Me.hsb05Hours.Size = New System.Drawing.Size(120, 39)
        Me.hsb05Hours.TabIndex = 3
        Me.hsb05Hours.TabStop = True
        '
        'btn05Calculate
        '
        Me.btn05Calculate.Location = New System.Drawing.Point(628, 353)
        Me.btn05Calculate.Name = "btn05Calculate"
        Me.btn05Calculate.Size = New System.Drawing.Size(112, 34)
        Me.btn05Calculate.TabIndex = 4
        Me.btn05Calculate.Text = "Calculate my calorie burn"
        Me.btn05Calculate.UseVisualStyleBackColor = True
        '
        'btn05Close
        '
        Me.btn05Close.Location = New System.Drawing.Point(628, 393)
        Me.btn05Close.Name = "btn05Close"
        Me.btn05Close.Size = New System.Drawing.Size(112, 34)
        Me.btn05Close.TabIndex = 5
        Me.btn05Close.Text = "Finish"
        Me.btn05Close.UseVisualStyleBackColor = True
        '
        'grp05DataEntry
        '
        Me.grp05DataEntry.Controls.Add(Me.grp05Results)
        Me.grp05DataEntry.Location = New System.Drawing.Point(617, 12)
        Me.grp05DataEntry.Name = "grp05DataEntry"
        Me.grp05DataEntry.Size = New System.Drawing.Size(300, 150)
        Me.grp05DataEntry.TabIndex = 11
        Me.grp05DataEntry.TabStop = False
        Me.grp05DataEntry.Text = "GroupBox1"
        '
        'grp05Results
        '
        Me.grp05Results.Location = New System.Drawing.Point(39, 68)
        Me.grp05Results.Name = "grp05Results"
        Me.grp05Results.Size = New System.Drawing.Size(300, 150)
        Me.grp05Results.TabIndex = 0
        Me.grp05Results.TabStop = False
        Me.grp05Results.Text = "GroupBox1"
        '
        'frm05CalorieBurnCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.grp05DataEntry)
        Me.Controls.Add(Me.btn05Close)
        Me.Controls.Add(Me.btn05Calculate)
        Me.Controls.Add(Me.hsb05Hours)
        Me.Controls.Add(Me.cbo05Exercise)
        Me.Controls.Add(Me.clx05Height)
        Me.Controls.Add(Me.txt05Age)
        Me.Controls.Add(Me.lbl05ScrollBar)
        Me.Controls.Add(Me.lbl05RecommendedBurn)
        Me.Controls.Add(Me.lbl05CalorieCount)
        Me.Controls.Add(Me.lbl05Recommended)
        Me.Controls.Add(Me.lbl05Calorie)
        Me.Controls.Add(Me.lbl05Hours)
        Me.Controls.Add(Me.lbl05Exercise)
        Me.Controls.Add(Me.lblWeight)
        Me.Controls.Add(Me.lbl05Height)
        Me.Controls.Add(Me.lbl05Age)
        Me.Controls.Add(Me.pbx05ExercisePicture)
        Me.Name = "frm05CalorieBurnCalculator"
        Me.Text = "Team 05 Calorie Burn Calculator"
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbx05ExercisePicture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grp05DataEntry.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FileSystemWatcher1 As IO.FileSystemWatcher
    Friend WithEvents lbl05Calorie As Label
    Friend WithEvents lbl05Hours As Label
    Friend WithEvents lbl05Exercise As Label
    Friend WithEvents lblWeight As Label
    Friend WithEvents lbl05Height As Label
    Friend WithEvents lbl05Age As Label
    Friend WithEvents pbx05ExercisePicture As PictureBox
    Friend WithEvents grp05DataEntry As GroupBox
    Friend WithEvents grp05Results As GroupBox
    Friend WithEvents btn05Close As Button
    Friend WithEvents btn05Calculate As Button
    Friend WithEvents hsb05Hours As HScrollBar
    Friend WithEvents cbo05Exercise As ComboBox
    Friend WithEvents clx05Height As CheckedListBox
    Friend WithEvents txt05Age As TextBox
    Friend WithEvents lbl05ScrollBar As Label
    Friend WithEvents lbl05RecommendedBurn As Label
    Friend WithEvents lbl05CalorieCount As Label
    Friend WithEvents lbl05Recommended As Label
End Class
