﻿Public Class frm05CalorieBurnCalculator
    Private Sub lbl05Exercise_Click(sender As Object, e As EventArgs) Handles lbl05Exercise.Click

    End Sub
End Class
